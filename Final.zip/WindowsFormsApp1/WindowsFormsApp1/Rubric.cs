﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Rubric : Form
    {
        public Rubric()
        {
            InitializeComponent();
            FormLoad();
            printCLO();
            printRubrics();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void FormLoad()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select id from CLO";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand= new SqlCommand(query,sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                comboBox1.Items.Add(reader["id"].ToString());
            }
            reader.Close();
            sqlConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Insert into Rubric(Id,Details,CloId) values(@Id,@Details,@CloId)";
            SqlConnection sqlConnection = new SqlConnection( conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query,sqlConnection);
          
            sqlCommand.Parameters.AddWithValue("@Details",textBox1.Text);
            sqlCommand.Parameters.AddWithValue("@CloId",comboBox1.Text);
            sqlCommand.Parameters.AddWithValue("@Id", textBox2.Text);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Rubric inserted");
            printRubrics();


           
        }
        private void printCLO()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";

            string query1 = "Select * from CLO ";
            SqlConnection sqlConnection1 = new SqlConnection(conn);
            sqlConnection1.Open();
            SqlCommand sqlCommand = new SqlCommand(query1, sqlConnection1);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);
            dataGridView1.DataSource = dataTable;
            reader.Close() ;
            sqlConnection1.Close();

        }
        private void printRubrics()
        {

            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";

            string query1 = "Select * from Rubric ";
            SqlConnection sqlConnection1 = new SqlConnection(conn);
            sqlConnection1.Open();
            SqlCommand sqlCommand = new SqlCommand(query1, sqlConnection1);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);
            dataGridView2.DataSource = dataTable;
            reader.Close() ;
            sqlConnection1.Close();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Update Rubric set Details=@Details,CloId=@CloId,Id=@Id";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

            sqlCommand.Parameters.AddWithValue("@Details", textBox1.Text);
            sqlCommand.Parameters.AddWithValue("@CloId", comboBox1.Text);
            sqlCommand.Parameters.AddWithValue("@Id", textBox2.Text);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Rubric Updated");
            printRubrics();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int rubric = 0;
            int id = int.Parse(textBox2.Text);
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Delete from Rubric where Id ='"+id+"'";
            string query1 = "Delete from RubricLevel where RubricId ='"+id+"'";
            string query2 = "Select Id from RubricLevel where RubricId ='"+id+"'";
            string query4 = "Select Id from Rubric where Id='"+id+"'";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlCommand sqlCommand1 = new SqlCommand(query1, sqlConnection);
            SqlCommand sqlCommand2 = new SqlCommand(query2, sqlConnection);
            SqlCommand sqlCommand4 = new SqlCommand(query4,sqlConnection);
            SqlDataReader reader = sqlCommand2.ExecuteReader();
            if (reader.Read())
            {
                rubric = Convert.ToInt32(reader["Id"]);
            }
            reader.Close();
            int componenet = 0;
            SqlDataReader sqlData = sqlCommand4.ExecuteReader();
            if(sqlData.Read())
            {
                componenet = Convert.ToInt32(sqlData["Id"]);
            }
            sqlData.Close();
            string query5 = "Delete from AssessmentComponent where RubricId ='"+componenet+"'";
            string query3 = "Delete from StudentResult where RubricMeasurementId= '"+rubric+"'";
            SqlCommand sqlCommand3 = new SqlCommand(query3, sqlConnection);
            SqlCommand sqlCommand5 = new SqlCommand(query5, sqlConnection);
            sqlCommand5.ExecuteNonQuery();
            sqlCommand3.ExecuteNonQuery();
            sqlCommand1.ExecuteNonQuery();
          
           
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Rubric Deleted");
            printRubrics();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var myForm = new Form1();
            myForm.Show();
        }
    }
}
