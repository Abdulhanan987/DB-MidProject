﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CLO : Form
    {
        public CLO()
        {
            InitializeComponent();
            printCLOs();
        }

        private void CLO_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Insert into CLO(Name,DateCreated,DateUpdated) Values(@Name,GETDATE(),GETDATE());";
            SqlConnection sqlConnection= new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand(query, sqlConnection);
            sql.Parameters.AddWithValue("Name",textBox1.Text);
            sql.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("CLO Added Suceesfully");
            printCLOs();

        }
        private void printCLOs()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select * from CLO;";
            SqlConnection sqlConnection = new SqlConnection( conn );
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);
            dataGridView1.DataSource = dataTable;
            reader.Close();
            sqlConnection.Close();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string ans = textBox1.Text;
            string query = "Update CLO Set DateUpdated=GETDATE() where Name = '"+ans+"'";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand( query, sqlConnection);
            sqlCommand.ExecuteNonQuery();
            MessageBox.Show("CLO Updated Suceesfully");
            printCLOs() ;

        }

        private void button3_Click(object sender, EventArgs e)
        {
           // DeleteRubric();
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string ans = textBox1.Text;
            string query = "Delete from CLO where Name='"+ans+"'";
            string query1 = "Select Id from Clo where Name='"+ans+"'";
            int Cloid = 0;
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlCommand sqlCommand1 = new SqlCommand(query1, sqlConnection);
            SqlDataReader reader = sqlCommand1.ExecuteReader();
            if(reader.Read())
            {
                Cloid = Convert.ToInt32(reader["Id"]);
            }
            reader.Close();
            int RubricId = 0;
            string query2 = "Delete from Rubric where CloId='"+Cloid+"'";
            string query3 = "Select Id from Rubric where CloId='"+Cloid+"'";
            SqlCommand sqlCommand2 = new SqlCommand(query2, sqlConnection);
            SqlCommand sqlCommand3 = new SqlCommand(query3, sqlConnection);
            SqlDataReader reader2 = sqlCommand3.ExecuteReader();
            if(reader2.Read())
            {
                RubricId = Convert.ToInt32(reader2["Id"]);
            }
            reader2.Close();
            int RubricLevel = 0;
            string query4 = "Delete from RubricLevel where RubricId='"+RubricId+"'";
            string query5 = "Select Id from RubricLevel where RubricId='"+RubricId+"'";
            SqlCommand sqlCommand4 = new SqlCommand(query4, sqlConnection);
            SqlCommand sqlCommand5 = new SqlCommand(query5, sqlConnection);
            SqlDataReader reader3 = sqlCommand5.ExecuteReader();
            if(reader3.Read())
            {
                RubricLevel = Convert.ToInt32(reader3["Id"]);
            }
            reader3.Close();
            int Ass = 0;
            string query6 = "Delete from StudentResult where RubricMeasurementId='"+RubricLevel+"'";
            string query7 = "Select AssessmentComponentId from StudentResult where RubricMeasurementId='"+RubricLevel+"'";
            SqlCommand sqlCommand6 = new SqlCommand(query6, sqlConnection);
            SqlCommand sqlCommand7 = new SqlCommand(query7, sqlConnection);
            SqlDataReader reader4= sqlCommand7.ExecuteReader();
            if(reader4.Read())
            {
                Ass= Convert.ToInt32(reader4["AssessmentComponentId"]);
            }
            reader4.Close();
            int assess = 0;
            string query8 = "Delete from AssessmentComponent where Id =' "+Ass+"'";
            string query9 = "Select AssessmentId from AssessmentComponent where Id=' "+Ass+"'";
            SqlCommand sqlCommand8 = new SqlCommand(query8, sqlConnection);
            SqlCommand sqlCommand9 = new SqlCommand(query9, sqlConnection);
            SqlDataReader reader5= sqlCommand9.ExecuteReader();
            if(reader5.Read())
            {
                assess = Convert.ToInt32(reader5["AssessmentId"]);
            }
            reader5.Close();
            string query10 = "Delete from Assessment where Id = '"+assess+"'";
            SqlCommand sqlCommand10 = new SqlCommand(query10, sqlConnection);
            sqlCommand6.ExecuteNonQuery();
            sqlCommand8.ExecuteNonQuery();
            sqlCommand10.ExecuteNonQuery();
            
            
            sqlCommand4.ExecuteNonQuery();
            sqlCommand2.ExecuteNonQuery();
            sqlCommand.ExecuteNonQuery();
            MessageBox.Show("CLO Deleted Suceesfully");
            printCLOs() ;

        }
        private void DeleteRubric()
        {
            int id=0;
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string ans = textBox1.Text;
            string query = "Select Id  from CLO where Name='" + ans + "'";
            SqlConnection sqlConnection = new SqlConnection( conn );
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query,sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            if(reader.Read())
            {
                id = Convert.ToInt32(reader["ID"]);
            }
            sqlConnection.Close();
            string conn1 = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query1 = "Delete from Rubric where CloId='"+id+"'";
            SqlConnection sqlConnection1 = new SqlConnection(conn1);
            sqlConnection1.Open();
            SqlCommand sqlCommand1 = new SqlCommand( query1,sqlConnection1);
            sqlCommand1.ExecuteNonQuery();
            sqlConnection1.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var myForm = new Form1();
            myForm.Show();
        }
    }
}
