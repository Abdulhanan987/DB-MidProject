﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Attendance : Form
    {
        public Attendance()
        {
            InitializeComponent();
            Loadd();
            load1();
            printAttendance();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Attendance_Load(object sender, EventArgs e)
        {

        }
        private void Loadd()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select RegistrationNumber from Student";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sql.ExecuteReader();
            while (reader.Read())
            {
                comboBox1.Items.Add(reader["RegistrationNumber"].ToString());

            }
            reader.Close();
            sqlConnection.Close();

        }
        private void load1()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select Name from Lookup where Category='ATTENDANCE_STATUS'";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sql.ExecuteReader();
            while (reader.Read())
            {
                comboBox2.Items.Add(reader["Name"].ToString());

            }
            reader.Close();
            sqlConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ClassAttend();
            int classid = ClassId();
            int stdid = StudentId();
            int statusid = StatusId();
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Insert into StudentAttendance values(@classid,@stdid,@statusid)";
            try
            {
                SqlConnection sqlConnection = new SqlConnection(conn);
                sqlConnection.Open();
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.Parameters.AddWithValue("@classid", classid);
                sqlCommand.Parameters.AddWithValue("@stdid", stdid);
                sqlCommand.Parameters.AddWithValue("@statusid", statusid);
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("This Student has been alredy taken present");
            }
            


           
            MessageBox.Show("Attendance saved");
            printAttendance();



        }
        private void ClassAttend()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Insert into ClassAttendance values (@AttendDate)";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand(query, sqlConnection);
            sql.Parameters.AddWithValue("@AttendDate", dateTimePicker1.Value);
            sql.ExecuteNonQuery();
            sqlConnection.Close();
        }
        private int ClassId()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
           DateTime dateTime = dateTimePicker1.Value;
            string query = "Select Id from ClassAttendance where AttendanceDate='"+dateTime+"'";
            SqlConnection sqlConnection = new SqlConnection( conn );
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            if (sqlDataReader.Read())
            {
                return Convert.ToInt32(sqlDataReader["id"]);
            }
            return 0;

        }
        private int StudentId()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string reg = comboBox1.Text;
            string query = "Select Id from Student where RegistrationNumber='" + reg + "'";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand( query, sqlConnection);
            SqlDataReader dataReader = sqlCommand.ExecuteReader();
            if (dataReader.Read())
            {
                
                return Convert.ToInt32(dataReader["id"]);
                dataReader.Close();
                sqlConnection.Close();
            }
            dataReader.Close();
            sqlConnection.Close();
            return 0;

        }
        private int StatusId()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string reg = comboBox2.Text;
            string query = "Select LookupId from LookUp where Name='" + reg + "'";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query,sqlConnection);
            SqlDataReader dataReader = sqlCommand.ExecuteReader();
            if (dataReader.Read())
            {
                
                return Convert.ToInt32(dataReader["LookupId"]);
                dataReader.Close();
                sqlConnection.Close();
            }
            dataReader.Close();
            sqlConnection.Close();
            return 0;
        }
        private void printAttendance()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select * from StudentAttendance";
            SqlConnection sqlConnection = new SqlConnection( conn );
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand( query,sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
           DataTable dataTable = new DataTable();
            dataTable.Load(reader);
            dataGridView1.DataSource = dataTable;
            reader.Close();
            sqlConnection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var myForm = new Form1();
            myForm.Show();
        }
    }
}
